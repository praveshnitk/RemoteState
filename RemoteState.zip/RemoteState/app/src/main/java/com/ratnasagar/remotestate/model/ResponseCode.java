package com.ratnasagar.remotestate.model;

public class ResponseCode {
    public static int PERMISSION_REQUEST_CODE =  100;
    public static long SPLASH_MILLIS = 2000;
}
